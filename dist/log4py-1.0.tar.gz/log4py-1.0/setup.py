from distutils.core import setup

setup(name='log4py', version='1.0', description='自定义日志', author='xiaoqiang')
